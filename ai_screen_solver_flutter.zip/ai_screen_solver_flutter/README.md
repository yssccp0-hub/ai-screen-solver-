# AI Screen Solver - Flutter Overlay App

Aplikasi Flutter Android yang membungkus **HTML AI Screen Scanner** agar dapat **tampil mengambang di atas aplikasi lain (`SYSTEM_ALERT_WINDOW`)** sekaligus menangkap layar secara otomatis (`MediaProjection`) dan menganalisis pertanyaan menggunakan **Gemini API**.

## Fitur Utama
1. **Tampil di Atas Aplikasi Lain (`flutter_overlay_window`)**: Dapat dikecilkan menjadi **Bola Bantu (Assistive Orb)** melayang yang bisa digeser ke mana saja, atau diperbesar menjadi panel jawaban.
2. **Auto-Scan Layar Real-Time (`MediaProjection` Native Android)**: Menangkap tampilan aplikasi lain di layar secara berkala (`Start Auto`) atau sekali ketuk (`Scan Sekarang`), lalu mengirimkannya ke Gemini API.
3. **UI HTML Terintegrasi (`assets/html/ai-assistive-scanner.html`)**: Mempertahankan seluruh desain, kontrol Start/Stop, pemilihan interval, model Gemini, dan tampilan hasil jawaban.

## Cara Build APK
1. Ekstrak file ZIP ini.
2. Pastikan Flutter SDK sudah terpasang (`flutter doctor`).
3. Jalankan perintah di folder project:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. File APK akan tersedia di `build/app/outputs/flutter-apk/app-release.apk`.

## Cara Penggunaan di HP Android
1. Buka aplikasi **AI Screen Solver**.
2. Tekan tombol **1. Izin Overlay** -> aktifkan *Display over other apps* untuk aplikasi ini.
3. Tekan tombol **2. Izin Scan Layar** -> tekan *Start now / Mulai sekarang* pada dialog izin tangkap layar Android.
4. Tekan **Tampilkan di Atas Aplikasi Lain**.
5. Buka aplikasi kuis/game/browser lain, lalu tekan **Start Auto** atau **Mode Bola Bantu** pada jendela mengambang.
