package com.ai.screensolver

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.ai.screensolver/native"
        private const val REQUEST_MEDIA_PROJECTION = 1001
    }

    private var pendingPermissionResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestScreenCapture" -> {
                        if (ScreenCaptureService.isReady()) {
                            result.success(true)
                            return@setMethodCallHandler
                        }
                        pendingPermissionResult = result
                        val projectionManager =
                            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        startActivityForResult(
                            projectionManager.createScreenCaptureIntent(),
                            REQUEST_MEDIA_PROJECTION
                        )
                    }

                    "captureScreen" -> {
                        if (!ScreenCaptureService.isReady()) {
                            result.error(
                                "NOT_READY",
                                "Tekan tombol '2. Izin Scan Layar' di aplikasi terlebih dahulu.",
                                null
                            )
                            return@setMethodCallHandler
                        }
                        val base64 = ScreenCaptureService.captureLatestFrameBase64()
                        if (base64 != null) {
                            result.success(base64)
                        } else {
                            result.error("CAPTURE_FAILED", "Gagal mengambil gambar layar.", null)
                        }
                    }

                    "stopScreenCapture" -> {
                        stopService(Intent(this, ScreenCaptureService::class.java))
                        result.success(true)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
                pendingPermissionResult?.success(true)
            } else {
                pendingPermissionResult?.success(false)
            }
            pendingPermissionResult = null
        }
    }
}
