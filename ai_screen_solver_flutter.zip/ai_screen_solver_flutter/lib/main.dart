import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:webview_flutter/webview_flutter.dart';

const MethodChannel _nativeChannel = MethodChannel('com.ai.screensolver/native');

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MainSolverApp());
}

/// Entry-point khusus jendela Floating Overlay (Tampil di Atas Aplikasi Lain)
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FloatingOverlayPage(),
    ),
  );
}

class MainSolverApp extends StatelessWidget {
  const MainSolverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Screen Solver',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090D16),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF38BDF8),
          secondary: Color(0xFF22C55E),
        ),
      ),
      home: const HomeControlPage(),
    );
  }
}

class HomeControlPage extends StatefulWidget {
  const HomeControlPage({super.key});

  @override
  State<HomeControlPage> createState() => _HomeControlPageState();
}

class _HomeControlPageState extends State<HomeControlPage> {
  bool _overlayGranted = false;
  bool _screenCaptureReady = false;
  bool _overlayActive = false;
  StreamSubscription? _overlaySub;
  late final WebViewController _webController;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
    _initWebView();
    _listenToOverlayRequests();
  }

  Future<void> _checkPermissions() async {
    final granted = await FlutterOverlayWindow.isPermissionGranted();
    final active = await FlutterOverlayWindow.isActive();
    if (mounted) {
      setState(() {
        _overlayGranted = granted;
        _overlayActive = active;
      });
    }
  }

  void _initWebView() {
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF090D16))
      ..addJavaScriptChannel(
        'FlutterBridge',
        onMessageReceived: (JavaScriptMessage message) async {
          final data = jsonDecode(message.message);
          if (data['action'] == 'CAPTURE_SCREEN') {
            final base64Frame = await _captureNativeScreen();
            final safeBase64 = jsonEncode(base64Frame);
            await _webController.runJavaScript(
              'window.onNativeScreenCaptured($safeBase64);',
            );
          }
        },
      )
      ..loadFlutterAsset('assets/html/ai-assistive-scanner.html');
  }

  /// Mendengarkan permintaan tangkap layar dari Floating Overlay di atas aplikasi lain
  void _listenToOverlayRequests() {
    _overlaySub = FlutterOverlayWindow.overlayListener.listen((event) async {
      if (event == 'REQ_CAPTURE') {
        final base64Frame = await _captureNativeScreen();
        await FlutterOverlayWindow.shareData({
          'type': 'SCREEN_FRAME',
          'base64': base64Frame,
        });
      }
    });
  }

  Future<String> _captureNativeScreen() async {
    try {
      final String? result =
          await _nativeChannel.invokeMethod<String>('captureScreen');
      return result ?? 'ERROR:Frame layar kosong';
    } on PlatformException catch (e) {
      return 'ERROR:${e.message ?? "Izin tangkap layar belum aktif"}';
    }
  }

  Future<void> _requestOverlayPermission() async {
    final granted = await FlutterOverlayWindow.requestPermission();
    setState(() {
      _overlayGranted = granted ?? false;
    });
  }

  Future<void> _requestScreenCapturePermission() async {
    try {
      final bool? ok =
          await _nativeChannel.invokeMethod<bool>('requestScreenCapture');
      if (mounted) {
        setState(() {
          _screenCaptureReady = ok ?? false;
        });
      }
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal mengaktifkan Screen Capture: ${e.message}')),
      );
    }
  }

  Future<void> _toggleFloatingOverlay() async {
    if (!_overlayGranted) {
      await _requestOverlayPermission();
      if (!_overlayGranted) return;
    }

    if (_overlayActive) {
      await FlutterOverlayWindow.closeOverlay();
      setState(() => _overlayActive = false);
      return;
    }

    await FlutterOverlayWindow.showOverlay(
      enableDrag: true,
      overlayTitle: "AI Screen Solver",
      overlayContent: "Bola Bantu AI aktif di atas layar",
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
      positionGravity: PositionGravity.none,
      width: 340,
      height: 460,
      startPosition: const OverlayPosition(20, 120),
    );
    setState(() => _overlayActive = true);
  }

  @override
  void dispose() {
    _overlaySub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'AI Screen Solver (Overlay)',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF0F172A),
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: const Color(0xFF0F172A),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _requestOverlayPermission,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _overlayGranted
                              ? const Color(0xFF16A34A)
                              : const Color(0xFF2563EB),
                          foregroundColor: Colors.white,
                        ),
                        icon: Icon(
                          _overlayGranted ? Icons.check_circle : Icons.layers,
                          size: 18,
                        ),
                        label: Text(
                          _overlayGranted ? '1. Overlay Aktif' : '1. Izin Overlay',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _requestScreenCapturePermission,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _screenCaptureReady
                              ? const Color(0xFF16A34A)
                              : const Color(0xFF0284C7),
                          foregroundColor: Colors.white,
                        ),
                        icon: Icon(
                          _screenCaptureReady
                              ? Icons.check_circle
                              : Icons.screenshot,
                          size: 18,
                        ),
                        label: Text(
                          _screenCaptureReady
                              ? '2. Scan Layar Siap'
                              : '2. Izin Scan Layar',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _toggleFloatingOverlay,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _overlayActive
                          ? const Color(0xFFDC2626)
                          : const Color(0xFF22C55E),
                      foregroundColor:
                          _overlayActive ? Colors.white : const Color(0xFF052E16),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    icon: Icon(
                      _overlayActive ? Icons.close : Icons.bubble_chart,
                    ),
                    label: Text(
                      _overlayActive
                          ? 'Matikan Bola Bantu Mengambang'
                          : 'Tampilkan di Atas Aplikasi Lain',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: WebViewWidget(controller: _webController),
          ),
        ],
      ),
    );
  }
}

/// Halaman yang dirender di dalam jendela Floating Overlay di atas semua aplikasi
class FloatingOverlayPage extends StatefulWidget {
  const FloatingOverlayPage({super.key});

  @override
  State<FloatingOverlayPage> createState() => _FloatingOverlayPageState();
}

class _FloatingOverlayPageState extends State<FloatingOverlayPage> {
  late final WebViewController _overlayWebController;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _overlayWebController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            _overlayWebController.runJavaScript(
              'window.setOverlayMode(true, false);',
            );
          },
        ),
      )
      ..addJavaScriptChannel(
        'FlutterBridge',
        onMessageReceived: (JavaScriptMessage msg) async {
          final data = jsonDecode(msg.message);
          final action = data['action'];
          if (action == 'CAPTURE_SCREEN') {
            await FlutterOverlayWindow.shareData('REQ_CAPTURE');
          } else if (action == 'RESIZE_ORB') {
            await FlutterOverlayWindow.resizeOverlay(78, 78, true);
          } else if (action == 'RESIZE_PANEL') {
            await FlutterOverlayWindow.resizeOverlay(340, 460, true);
          }
        },
      )
      ..loadFlutterAsset('assets/html/ai-assistive-scanner.html');

    _sub = FlutterOverlayWindow.overlayListener.listen((event) async {
      if (event is Map && event['type'] == 'SCREEN_FRAME') {
        final safeBase64 = jsonEncode(event['base64'] ?? '');
        await _overlayWebController.runJavaScript(
          'window.onNativeScreenCaptured($safeBase64);',
        );
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: WebViewWidget(controller: _overlayWebController),
    );
  }
}
